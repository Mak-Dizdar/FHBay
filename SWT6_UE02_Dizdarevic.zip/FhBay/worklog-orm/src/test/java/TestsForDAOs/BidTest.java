package TestsForDAOs;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import swt6.DAOs.ArticleDAO;
import swt6.DAOs.BidDAO;
import swt6.DAOs.CustomerDAO;
import swt6.DAOs.impl.FactoryDAO;
import swt6.orm.domain.Article;
import swt6.orm.domain.Bid;
import swt6.orm.domain.Customer;
import swt6.util.JpaUtil;

import static swt6.orm.domain.ArticleStatus.SOLD;

public class BidTest {

    ArticleDAO articles = FactoryDAO.getArticleDAO();
    CustomerDAO customers = FactoryDAO.getCustomerDAO();
    BidDAO bids = FactoryDAO.getBidDAO();

    @AfterEach
    void afterEach(){
        JpaUtil.resetTable("Bid");
    }

    @AfterAll
    static void cleanAfterAll(){
        JpaUtil.resetTable("Article");
        JpaUtil.resetTable("Customer");
    }

    @Test
    void testGetBestBid(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        articles.insert(article);
        var bidCustomer1 = new Bid(170, article, customer1);
        var bidCustomer2 = new Bid(250, article, customer2);
        bids.insert(bidCustomer1);
        bids.insert(bidCustomer2);

        var founded = bids.getBestBid(article);
        Assertions.assertEquals(bidCustomer2.getAmount(), founded.getAmount());
    }


}
