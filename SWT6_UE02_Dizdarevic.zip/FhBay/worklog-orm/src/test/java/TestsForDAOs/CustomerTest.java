package TestsForDAOs;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import swt6.DAOs.CustomerDAO;
import swt6.DAOs.impl.FactoryDAO;
import swt6.orm.domain.Address;
import swt6.orm.domain.Customer;
import swt6.util.JpaUtil;

public class CustomerTest {
    CustomerDAO customers = FactoryDAO.getCustomerDAO();

    @AfterEach
    void afterEach(){
        JpaUtil.resetTable("Customer");
    }

    @Test
    void testInsert(){
        var addr = new Address(4230, "Pregarten", "Gutauer Straße", 45);
        Customer customer = new Customer("Hazret", "Dizdarevic");
        customer.setAddress(addr);
        customers.insert(customer);

        Assertions.assertNotNull(customer.getCustomerID());
    }

    @Test
    void testUpdate(){
        var addr = new Address(4230, "Pregarten", "Gutauer Straße", 45);
        Customer customer = new Customer("Hazret", "Dizdarevic");
        customer.setAddress(addr);
        customers.insert(customer);

        var newAddr = new Address(4230, "Pregarten", "Gutauer Straße", 44);
        customer.setAddress(newAddr);
        customer = customers.update(customer.getCustomerID(), customer);
        Assertions.assertEquals(newAddr, customer.getAddress());
    }

    @Test
    void testDelete(){
        var addr = new Address(4230, "Pregarten", "Gutauer Straße", 45);
        Customer customer = new Customer("Hazret", "Dizdarevic");
        customer.setAddress(addr);
        customers.insert(customer);

        customers.remove(customer);
        var deleted = customers.getByID(customer.getCustomerID());
    }

    @Test
    void testGetByID(){
        var addr = new Address(4230, "Pregarten", "Gutauer Straße", 45);
        Customer customer = new Customer("Hazret", "Dizdarevic");
        customer.setAddress(addr);
        customers.insert(customer);

        var id = customers.getByID(customer.getCustomerID());
        Assertions.assertEquals(customer.getCustomerID(),id.getCustomerID());

    }

    @Test
    void testGetAll(){
        var addr = new Address(4230, "Pregarten", "Gutauer Straße", 45);
        Customer customer = new Customer("Hazret", "Dizdarevic");
        customer.setAddress(addr);
        customers.insert(customer);

        var all = customers.getAllCustomers();
        Assertions.assertEquals(1, all.size());
    }

}
