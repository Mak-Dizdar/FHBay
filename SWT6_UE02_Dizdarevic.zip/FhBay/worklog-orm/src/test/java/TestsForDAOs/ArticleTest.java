package TestsForDAOs;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import swt6.DAOs.ArticleDAO;
import swt6.DAOs.CustomerDAO;
import swt6.DAOs.impl.FactoryDAO;
import swt6.orm.domain.Article;
import swt6.orm.domain.Customer;
import swt6.util.JpaUtil;

import static swt6.orm.domain.ArticleStatus.SOLD;

public class ArticleTest {

    ArticleDAO articles = FactoryDAO.getArticleDAO();
    CustomerDAO customers = FactoryDAO.getCustomerDAO();

    @AfterEach
    void afterEach(){
        JpaUtil.resetTable("Article");
    }

    @AfterAll
    static void cleanAfterAll(){
        JpaUtil.resetTable("Customer");
    }

    @Test
    void testInsert(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);
        Assertions.assertNotNull(article.getId());
    }

    @Test
    void testUpdate(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        article.setName("LG");
        article = articles.update(article.getId(), article);
        Assertions.assertEquals("LG", article.getName());
    }

    @Test
    void testRemove(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        articles.remove(article);
        var removed = articles.getByID(article.getId());
        Assertions.assertNull(removed);
    }

    @Test
    void testGetById(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        var id = articles.getByID(article.getId());
        Assertions.assertEquals(article.getId(), id.getId());
    }

    @Test
    void testFindByStatus(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        var founded = articles.findByStatus(SOLD);

        for(Article a: founded) {
            Assertions.assertEquals(article.getName(), a.getName());
        }
    }

    @Test
    void testFindByNameOrDescription(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        var founded = articles.findByNameOrDescription("Samsung");

        for(Article a: founded) {
            Assertions.assertEquals(article.getName(), a.getName());
        }
    }

    @Test
    void testFindBySeller(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        var founded = articles.findBySeller(customer2);
        Assertions.assertEquals(1, founded.size());
    }

    @Test
    void testFindByBuyer(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        var founded = articles.findByBuyer(customer3);
        Assertions.assertEquals(1, founded.size());
    }

    @Test
    void testFindByBidder(){
        Customer customer1 = new Customer("Hazret", "Dizdarevic");
        Customer customer2 = new Customer("Mitar", "Miric");
        Customer customer3 = new Customer("Jala", "Brat");
        Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);
        customers.insert(customer1);
        customers.insert(customer2);
        customers.insert(customer3);
        articles.insert(article);

        var founded = articles.findByBidder(customer1);
        Assertions.assertEquals(1, founded.size());
    }

}
