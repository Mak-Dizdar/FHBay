package swt6.client;

import swt6.DAOs.impl.FactoryDAO;
import swt6.orm.domain.*;
import swt6.util.JpaUtil;

import javax.persistence.EntityManager;

import java.util.Set;

import static swt6.orm.domain.ArticleStatus.SOLD;

public class Client {

 public static void main(String[] args){
     JpaUtil.getEntityManagerFactory();
     try {
         var customers = FactoryDAO.getCustomerDAO();
         var articles = FactoryDAO.getArticleDAO();
         var bids = FactoryDAO.getBidDAO();


         //Inserting values
         System.out.println(">>>>>>>>>>>>INSERTING VALUES<<<<<<<<<<<<");
         Customer customer1 = new Customer("Hazret", "Dizdarevic");
         Customer customer2 = new Customer("Mitar", "Miric");
         Customer customer3 = new Customer("Jala", "Brat");

         Address address = new Address(4230, "Pregarten", "Gutauer Straße", 45);
         customer1.setAddress(address);

         BankAccount payment = new BankAccount("AT12 3333 3333 3333 3333","BTZLDS", "Hazret Dizdarevic");

         Article article = new Article("Samsung", "LCD Monitor", 150, 250, customer2, customer3, customer1, SOLD);


         customer3.addPayment(payment);

         customers.insert(customer1);
         customers.insert(customer2);
         customers.insert(customer3);

         articles.insert(article);

         var bidCustomer1 = new Bid(150, article, customer1);
         var bidCustomer3 = new Bid(250, article, customer3);
         bids.insert(bidCustomer1);
         bids.insert(bidCustomer3);

         JpaUtil.commit();;

         System.out.println("<<<<<<TESTING CUSTOMER>>>>>>>>>");
         var foundCustomerByLastname = customers.getByLastName("DIZDAREVIC");
         foundCustomerByLastname.forEach(fb -> System.out.println(
                 "Customer with lastname 'DIZDAREVIC' " + fb.toString()
         ));


         System.out.println("<<<<<<<<<<All Customers>>>>>>>>>>>");
         var allCustomers = customers.getAllCustomers();
         allCustomers.forEach(fb -> {
             System.out.println("Customer => " + fb.toString());
             System.out.println();
         });


         System.out.println("<<<<<<TESTING ARTICLE METHODS>>>>>>>>>");
         var foundedByStatus = articles.findByStatus(SOLD);
         foundedByStatus.forEach(fb -> {
             System.out.println("Finding based on Status 1: " + fb.toString());
         });

         var foundedBySeller = articles.findBySeller(customer2);
         foundedBySeller.forEach(fb -> {
             System.out.println("Finding based on Seller 2: " + fb.toString());
         });

         var foundedByBidder = articles.findByBidder(customer1);
         foundedByBidder.forEach(fb -> {
             System.out.println("Finding based on Bidder 3: " + fb.toString());
         });

         var foundedByNameOrDescription = articles.findByNameOrDescription("LCD");
         foundedByNameOrDescription.forEach(fb -> {
             System.out.println("Finding based on Description 4:" + fb.toString());
         });

         System.out.println("<<<<<<<<<Testing Bids>>>>>>>>>>>>");
         var bestBid = bids.getBestBid(article);
         System.out.println("Best bid is: " + bestBid.toString());

         JpaUtil.commit();
     }catch (Exception e){
        JpaUtil.rollback();
        throw e;
     }
 }
}
