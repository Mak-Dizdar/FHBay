package swt6.DAOs;

import swt6.orm.domain.BankAccount;

public interface BankAccountDAO extends BaseForDAOs<BankAccount> {

}
