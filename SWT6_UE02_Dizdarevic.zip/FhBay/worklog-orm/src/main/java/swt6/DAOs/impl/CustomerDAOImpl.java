package swt6.DAOs.impl;

import swt6.DAOs.CustomerDAO;
import swt6.orm.domain.Address;
import swt6.orm.domain.Customer;
import swt6.util.JpaUtil;

import java.util.List;

public class CustomerDAOImpl extends BaseForDAOsImpl<Customer> implements CustomerDAO {
    @Override
    protected Class<Customer> getType() {
        return Customer.class;
    }

    @Override
    public List<Customer> getAllCustomers() {
        var em = JpaUtil.getTransactedEntityManager();
        var allCustomers = em.createQuery("select c from Customer c", getType()).getResultList();
        return allCustomers;
    }

    @Override
    public List<Customer> getByLastName(String lastname) {
        var em = JpaUtil.getTransactedEntityManager();
        var cb = em.getCriteriaBuilder();
        var query = cb.createQuery(Customer.class);
        var entity = query.from(Customer.class);
        var lowerName = lastname.toLowerCase();
        var listOfCustomers = query.select(entity)
                .where(cb.equal(cb.lower(entity.get("lastname")), lowerName));
        return em.createQuery(listOfCustomers).getResultList();

    }
}
