package swt6.DAOs.impl;

import swt6.DAOs.AddressDAO;
import swt6.DAOs.BaseForDAOs;
import swt6.orm.domain.Address;
import swt6.util.JpaUtil;

import javax.persistence.EntityManager;
import java.util.List;

public class AddressDAOImpl extends BaseForDAOsImpl<Address> implements AddressDAO {
    @Override
    protected Class<Address> getType() {
        return Address.class;
    }
}
