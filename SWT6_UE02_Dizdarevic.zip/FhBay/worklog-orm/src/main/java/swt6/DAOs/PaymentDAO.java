package swt6.DAOs;

import swt6.orm.domain.Payment;

public interface PaymentDAO extends BaseForDAOs<Payment> {
}
