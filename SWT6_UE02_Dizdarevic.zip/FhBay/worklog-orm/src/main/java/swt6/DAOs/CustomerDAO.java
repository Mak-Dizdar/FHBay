package swt6.DAOs;

import swt6.orm.domain.Address;
import swt6.orm.domain.Customer;

import java.util.List;

public interface CustomerDAO extends BaseForDAOs<Customer> {
    List<Customer> getAllCustomers();
    List<Customer> getByLastName(String lastname);


}
