package swt6.DAOs.impl;

import swt6.DAOs.ArticleDAO;
import swt6.orm.domain.Article;
import swt6.orm.domain.ArticleStatus;
import swt6.orm.domain.Customer;
import swt6.util.JpaUtil;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Locale;

public class ArticleDAOImpl extends BaseForDAOsImpl<Article> implements ArticleDAO {
    @Override
    public List<Article> findByNameOrDescription(String NameOrDescription) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        var cb = em.getCriteriaBuilder();
        var query = cb.createQuery(Article.class);
        var entity = query.from(Article.class);
        var listOfArticles = query.select(entity).
                where(cb.or((cb.like(cb.lower(entity.get("name")), "%" + NameOrDescription.toLowerCase() + "%")),
                        (cb.like(cb.lower(entity.get("description")), "%" + NameOrDescription.toLowerCase() + "%"))));

        return em.createQuery(listOfArticles).getResultList();
    }



    @Override
    public List<Article> findByStatus(ArticleStatus status) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        var cb = em.getCriteriaBuilder();
        var query = cb.createQuery(Article.class);
        var entity = query.from(Article.class);

        var listOfArticles = query.select(entity)
                .where(cb.equal(entity.get("articleStatus"), status));

        return em.createQuery(listOfArticles).getResultList();
    }

    @Override
    public List<Article> findByBuyer(Customer customer) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        var listOfArticles = em.createQuery("select a from Article a where a.buyer.id =: customerID");
        listOfArticles.setParameter("customerID", customer.getCustomerID());
        return listOfArticles.getResultList();
    }

    @Override
    public List<Article> findBySeller(Customer customer) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        var listOfArticles = em.createQuery("select a from Article a where a.seller.id =: customerID");
        listOfArticles.setParameter("customerID", customer.getCustomerID());
        return listOfArticles.getResultList();
    }

    @Override
    public List<Article> findByBidder(Customer customer) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        var listOfArticles = em.createQuery("select a from Article a where a.bidder.id =: customerID");
        listOfArticles.setParameter("customerID", customer.getCustomerID());
        return listOfArticles.getResultList();
    }


    @Override
    protected Class<Article> getType() {
        return Article.class;
    }
}
