package swt6.DAOs;

import swt6.orm.domain.Article;
import swt6.orm.domain.Bid;

public interface BidDAO extends BaseForDAOs<Bid> {
    Bid getBestBid(Article article);
}
