package swt6.DAOs;

import swt6.orm.domain.Address;

import java.util.List;

public interface AddressDAO extends BaseForDAOs<Address> {
}
