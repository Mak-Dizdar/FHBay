package swt6.DAOs.impl;

import swt6.DAOs.BaseForDAOs;
import swt6.DAOs.PaymentDAO;
import swt6.orm.domain.Payment;

public class PaymentDAOImpl extends BaseForDAOsImpl<Payment> implements PaymentDAO {
    @Override
    protected Class<Payment> getType() {
        return Payment.class;
    }
}
