package swt6.DAOs;
import java.util.List;


public interface BaseForDAOs<T> {
    T getByID(Long id);
    void insert(T entity);
    T update(Long id, T entity);
    void remove(T entity);
    List<T> getAll();
}
