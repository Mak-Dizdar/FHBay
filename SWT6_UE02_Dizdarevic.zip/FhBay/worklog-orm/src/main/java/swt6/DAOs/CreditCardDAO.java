package swt6.DAOs;

import swt6.orm.domain.CreditCard;

public interface CreditCardDAO extends BaseForDAOs<CreditCard>{
}
