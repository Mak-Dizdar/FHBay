package swt6.DAOs.impl;

import swt6.DAOs.BaseForDAOs;
import swt6.util.JpaUtil;

import javax.persistence.EntityManager;
import java.util.List;

public abstract class BaseForDAOsImpl<T> implements BaseForDAOs<T> {
    protected abstract Class<T> getType();

    @Override
    public T getByID(Long id) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        return em.find(getType(), id);

    }

    @Override
    public void insert(T entity) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        em.persist(entity);
    }

    @Override
    public T update(Long id, T entity) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        T entityToUpdate = em.find(getType(), id);
        if(entityToUpdate == null)
            throw new IllegalCallerException("Entity with specified ID cannot be found");
        entityToUpdate = em.merge(entity);
        return  entityToUpdate;

    }

    @Override
    public void remove(T entity) {
        EntityManager em = JpaUtil.getTransactedEntityManager();
        entity = em.merge(entity);
        try {
            em.remove(entity);
        }catch (Exception e){
            throw  new IllegalCallerException("Entity cannot be found");
        }

    }

    @Override
    public List<T> getAll() {
        EntityManager em = JpaUtil.getTransactedEntityManager();

        return null;
    }
}
