package swt6.DAOs.impl;

import swt6.DAOs.ArticleDAO;
import swt6.DAOs.BidDAO;
import swt6.DAOs.CustomerDAO;
import swt6.DAOs.PaymentDAO;

public class FactoryDAO {
    private static CustomerDAO customerDAO;
    private static BidDAO bidDAO;
    private static PaymentDAO paymentDAO;
    private static ArticleDAO articleDAO;

    public static CustomerDAO getCustomerDAO() {
        if(customerDAO == null)
            customerDAO = new CustomerDAOImpl();
        return customerDAO;
    }

    public static BidDAO getBidDAO() {
        if(bidDAO == null)
            bidDAO = new BidDAOImpl();
        return bidDAO;
    }

    public static PaymentDAO getPaymentDAO() {
        if(paymentDAO == null)
            paymentDAO = new PaymentDAOImpl();
        return paymentDAO;
    }

    public static ArticleDAO getArticleDAO() {
        if(articleDAO == null)
            articleDAO = new ArticleDAOImpl();
        return articleDAO;
    }
}
