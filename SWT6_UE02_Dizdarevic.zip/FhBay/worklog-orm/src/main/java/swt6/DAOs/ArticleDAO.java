package swt6.DAOs;

import swt6.orm.domain.Article;
import swt6.orm.domain.ArticleStatus;
import swt6.orm.domain.Customer;

import java.util.List;

public interface ArticleDAO extends BaseForDAOs<Article> {
    List<Article> findByNameOrDescription(String NameOrDescription);
    List<Article> findByStatus(ArticleStatus status);
    List<Article> findByBuyer(Customer customer);
    List<Article> findBySeller(Customer customer);
    List<Article> findByBidder(Customer customer);
}
