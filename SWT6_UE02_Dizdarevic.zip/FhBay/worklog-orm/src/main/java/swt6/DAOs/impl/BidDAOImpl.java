package swt6.DAOs.impl;

import swt6.DAOs.BidDAO;
import swt6.orm.domain.Article;
import swt6.orm.domain.Bid;
import swt6.util.JpaUtil;

import javax.persistence.criteria.Order;

public class BidDAOImpl extends BaseForDAOsImpl<Bid> implements BidDAO {
    @Override
    protected Class<Bid> getType() {
        return Bid.class;
    }

    @Override
    public Bid getBestBid(Article article) {
        var em = JpaUtil.getTransactedEntityManager();
        var cb = em.getCriteriaBuilder();
        var query = cb.createQuery(Bid.class);
        var entity = query.from(Bid.class);
        var bestBid = query.select(entity)
                .where(cb.equal(entity.get("article"), article))
                .orderBy(cb.desc(entity.get("amount")));
        return em.createQuery(bestBid).setMaxResults(1).getSingleResult();
    }
}
