package swt6.orm.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Customer implements Serializable {

    @Id
    @GeneratedValue
    private Long customerID;

    @Column(nullable = false)
    private String firstname;
    @Column(nullable = false)
    private String lastname;

    private String email;

    @Column(nullable = false)
    @Embedded
    @AttributeOverride(name = "zipCode", column = @Column(name = "zipCode"))
    @AttributeOverride(name = "city", column = @Column(name = "city"))
    @AttributeOverride(name = "street", column = @Column(name = "street"))
    @AttributeOverride(name = "houseNumber", column = @Column(name = "houseNumber"))

    private Address address;




    @Embedded
    @AttributeOverride(name = "zipCode", column = @Column(name = "ZipCodeOfDelivery"))
    @AttributeOverride(name = "city", column = @Column(name = "CityOfDelivery"))
    @AttributeOverride(name = "street", column = @Column(name = "StreetOfDelivery"))
    @AttributeOverride(name = "houseNumber", column = @Column(name = "houseNumberOfDelivery"))
    private Address deliveryAddress;

    @Embedded
    @AttributeOverride(name = "zipCode", column = @Column(name = "ZipCodeForBilling"))
    @AttributeOverride(name = "city", column = @Column(name = "CityForBilling"))
    @AttributeOverride(name = "street", column = @Column(name = "StreetForBilling"))
    @AttributeOverride(name = "houseNumber", column = @Column(name = "houseNumberForBilling"))
    private Address billingAddress;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<Payment> payment = new HashSet<>();

    public Customer(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    public Customer(){}

    public Long getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Long customerID) {
        this.customerID = customerID;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Address getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(Address deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public Address getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void addPayment(Payment payment){
        if(payment.getCustomer() != null)
            payment.getCustomer().getPayment().remove(payment);
        this.payment.add(payment);
        payment.setCustomer(this);
    }
    public Set<Payment> getPayment() {
        return payment;
    }

    public void setPayment(Set<Payment> payment) {
        this.payment = payment;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Customer{");
        sb.append("customerID=").append(customerID);
        sb.append(", firstname='").append(firstname).append('\'');
        sb.append(", lastname='").append(lastname).append('\'');
        sb.append(", email='").append(email).append('\'');
        if(address != null){
            sb.append("\n");
            sb.append(address);
        }
        if(deliveryAddress != null)
            sb.append(", deliveryAddress=").append(deliveryAddress);
        if(billingAddress != null)
            sb.append(", billingAddress=").append(billingAddress);
        if(payment != null)
            sb.append(", payment=").append(payment);
        sb.append('}');
        return sb.toString();
    }
}
