package swt6.orm.domain;

import javax.persistence.*;

@Entity
public class Bid {
    @Id
    @GeneratedValue
    private long id;
    private int amount;
    @ManyToOne(fetch = FetchType.EAGER)
    private Article article;
    @ManyToOne(fetch = FetchType.EAGER)
    private Customer bidder;

    public Bid(int amount, Article article, Customer bidder) {
        this.amount = amount;
        this.article = article;
        this.bidder = bidder;
    }
    public Bid(){}

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Article getArticle() {
        return article;
    }

    public void setArticle(Article article) {
        this.article = article;
    }

    public Customer getBidder() {
        return bidder;
    }

    public void setBidder(Customer bidder) {
        this.bidder = bidder;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Bid{");
        sb.append("amount=").append(amount).append("\n");
        sb.append(", article=").append(article.toString()).append("\n");
        sb.append(", bidder=").append(bidder.toString()).append(("\n"));
        sb.append('}');
        return sb.toString();
    }
}
