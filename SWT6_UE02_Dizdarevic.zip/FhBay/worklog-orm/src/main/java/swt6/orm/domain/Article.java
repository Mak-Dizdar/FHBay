package swt6.orm.domain;

import org.hibernate.annotations.Fetch;

import javax.persistence.*;
import java.io.Serializable;
import java.util.StringJoiner;

@Entity
public class Article implements Serializable {
    @Id  @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String          name;
    @Column(nullable = false)
    private String          description;
    @Column(nullable = false)
    private int             startingPrice;
    private int             finalPrice;
    @ManyToOne(optional = false)
    @JoinColumn(name = "id_seller")
    private Customer        seller;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_buyer")
    private Customer        buyer;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_bidder")
    private Customer        bidder;
    private ArticleStatus   articleStatus;

    public Article(String name, String description, int startingPrice,
                   int finalPrice, Customer seller, Customer buyer,
                   Customer bidder, ArticleStatus articleStatus) {
        this.name = name;
        this.description = description;
        this.startingPrice = startingPrice;
        this.finalPrice = finalPrice;
        this.seller = seller;
        this.buyer = buyer;
        this.bidder = bidder;
        this.articleStatus = articleStatus;
    }
    public Article(){}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getStartingPrice() {
        return startingPrice;
    }

    public void setStartingPrice(int startingPrice) {
        this.startingPrice = startingPrice;
    }

    public int getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(int finalPrice) {
        this.finalPrice = finalPrice;
    }

    public Customer getSeller() {
        return seller;
    }

    public void setSeller(Customer seller) {
        this.seller = seller;
    }

    public Customer getBuyer() {
        return buyer;
    }

    public void setBuyer(Customer buyer) {
        this.buyer = buyer;
    }

    public Customer getBidder() {
        return bidder;
    }

    public void setBidder(Customer bidder) {
        this.bidder = bidder;
    }

    public ArticleStatus getArticleStatus() {
        return articleStatus;
    }

    public void setArticleStatus(ArticleStatus articleStatus) {
        this.articleStatus = articleStatus;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Article{");
        sb.append("name='").append(name).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", startingPrice=").append(startingPrice);
        sb.append(", finalPrice=").append(finalPrice);
        //sb.append(", seller=").append(seller);
        //sb.append(", buyer=").append(buyer);
        //sb.append(", bidder=").append(bidder);
        sb.append(", articleStatus=").append(articleStatus);
        sb.append('}');
        return sb.toString();
    }
}
