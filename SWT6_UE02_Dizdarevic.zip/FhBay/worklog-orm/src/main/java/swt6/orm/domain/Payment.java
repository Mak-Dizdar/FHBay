package swt6.orm.domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("pp")
public class Payment implements Serializable {
    @Id @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String paymentOwner;
    @ManyToOne
    private Customer customer;


    public Payment(String paymentOwner) {
        this.paymentOwner = paymentOwner;
    }
    public Payment(){

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPaymentOwner() {
        return paymentOwner;
    }

    public void setPaymentOwner(String paymentOwner) {
        this.paymentOwner = paymentOwner;
    }

    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
