package swt6.orm.domain;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@DiscriminatorValue("cc")

public class CreditCard extends Payment{

    private long CreditCardNumber;
    private LocalDateTime expirationDate;

    public CreditCard(long creditCardNumber, LocalDateTime expirationDate, String name) {
        super(name);
        CreditCardNumber = creditCardNumber;
        this.expirationDate = expirationDate;
    }
    public CreditCard(){}

    public long getCreditCardNumber() {
        return CreditCardNumber;
    }

    public void setCreditCardNumber(long creditCardNumber) {
        CreditCardNumber = creditCardNumber;
    }

    public LocalDateTime getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDateTime expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", CreditCard.class.getSimpleName() + "[", "]")
                .add("CreditCardNumber=" + CreditCardNumber)
                .add("expirationDate=" + expirationDate)
                .toString();
    }
}
