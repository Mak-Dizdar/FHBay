package swt6.orm.domain;

public enum ArticleStatus {
    SOLD, NOT_FOR_SALE, OFFERED
}
