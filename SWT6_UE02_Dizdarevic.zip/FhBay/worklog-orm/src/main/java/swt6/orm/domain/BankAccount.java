package swt6.orm.domain;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import java.util.StringJoiner;

@Entity
@DiscriminatorValue("ba")
public class BankAccount extends Payment{
    @Column(nullable = false)
    private String IBAN;
    private String BIC;

    public BankAccount(String IBAN, String BIC, String name) {
        super(name);
        this.IBAN = IBAN;
        this.BIC = BIC;
    }
    public BankAccount(){}

    public String getIBAN() {
        return IBAN;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }

    public String getBIC() {
        return BIC;
    }

    public void setBIC(String BIC) {
        this.BIC = BIC;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", BankAccount.class.getSimpleName() + "[", "]")
                .add("IBAN='" + IBAN + "'")
                .add("BIC='" + BIC + "'")
                .toString();
    }
}
